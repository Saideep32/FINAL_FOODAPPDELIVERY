export const itemData = [{
        item_img: "/assets/item/Bonda.jpg"

    },
    {
        item_img: "/assets/item/Dosa.jpg"
    },
    {
        item_img: "/assets/item/Idli.jpg"
    },
    {
        item_img: "/assets/item/Juice.jpg"
    },
    {
        item_img: "/assets/item/Pancake.jpg"
    },
    {
        item_img: "/assets/item/Paratha.jpg"
    },
    {
        item_img: "/assets/item/Poha.jpg"
    },
    {
        item_img: "/assets/item/Poori.jpg"
    },
    {
        item_img: "/assets/item/Vada.jpg"
    },

]